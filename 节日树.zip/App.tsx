import React, { useState, useEffect, useRef, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Loader } from '@react-three/drei';
import { FilesetResolver, GestureRecognizer } from '@mediapipe/tasks-vision';
import * as THREE from 'three';
import { TreeState } from './types';
import { TreeParticles } from './components/TreeParticles';
import { PhotoParticles } from './components/PhotoParticles';
import { Fireworks } from './components/Fireworks';
import { Environment } from './components/Environment';
import { UI } from './components/UI';

// Shared state object to pass data from MediaPipe (outside React loop) to Three.js (inside Canvas)
// x: normalized hand position (0 to 1)
// active: is hand currently open?
const gestureState = { x: 0.5, active: false };

const InteractiveGroup: React.FC<{ mode: TreeState; children: React.ReactNode }> = ({ mode, children }) => {
  const groupRef = useRef<THREE.Group>(null);
  
  // Target values (Where we want to go)
  const targetPos = useRef(new THREE.Vector3(0, 0, 0));
  const targetScale = useRef(1);
  const targetRotY = useRef(0);

  // Input smoothing (Where the hand is "effectively" at)
  const smoothX = useRef(0.5);

  useFrame((state, delta) => {
    if (!groupRef.current) return;

    // 1. INPUT SMOOTHING
    // Filter out jitter from the camera tracking
    // If active, move smoothX towards the raw gesture X. 
    // If inactive, drift back to center (0.5).
    const rawTargetX = (mode === TreeState.SCATTERED && gestureState.active) ? gestureState.x : 0.5;
    
    // Lerp factor for input: Higher = more responsive, Lower = smoother but laggy
    smoothX.current = THREE.MathUtils.lerp(smoothX.current, rawTargetX, 3 * delta);

    // 2. INTERACTION LOGIC
    if (mode === TreeState.SCATTERED && gestureState.active) {
      // Pan: Map smoothed X (0..1) to Scene X (-35..35)
      // Invert direction for natural mirror feeling
      const xOffset = (0.5 - smoothX.current) * 35; 
      targetPos.current.set(xOffset, 0, 0);
      
      // Rotation: Map smoothed X to Y-axis rotation
      // +/- 70 degrees max rotation for a natural look
      targetRotY.current = (0.5 - smoothX.current) * Math.PI * 0.8;

      // Zoom
      targetScale.current = 1.6;
    } else {
      // Reset defaults
      targetPos.current.set(0, 0, 0);
      targetScale.current = 1;
      targetRotY.current = 0;
    }

    // 3. PHYSICS SMOOTHING (Inertia)
    // This gives the object "weight" as it moves
    const damping = 2.5 * delta; 
    
    // Apply Position
    groupRef.current.position.lerp(targetPos.current, damping);
    
    // Apply Scale
    const currentScale = groupRef.current.scale.x;
    const nextScale = THREE.MathUtils.lerp(currentScale, targetScale.current, damping);
    groupRef.current.scale.setScalar(nextScale);

    // Apply Rotation
    // Smoothly rotate towards target angle
    groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, targetRotY.current, damping);
  });

  return <group ref={groupRef}>{children}</group>;
};

const App: React.FC = () => {
  const [mode, setMode] = useState<TreeState>(TreeState.TREE_SHAPE);
  const modeRef = useRef<TreeState>(TreeState.TREE_SHAPE);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const [cameraLoaded, setCameraLoaded] = useState(false);
  const [isCameraEnabled, setIsCameraEnabled] = useState(true);
  
  // Photo State
  const [photos, setPhotos] = useState<string[]>([]);
  const [zoomedPhoto, setZoomedPhoto] = useState<string | null>(null);

  // Audio State
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);

  useEffect(() => {
    // Setup background music: Last Christmas (Synth/Instrumental Style)
    // Using a direct CDN link that is more reliable
    const audio = new Audio("https://cdn.pixabay.com/audio/2022/11/22/audio_c0c5921869.mp3");
    audio.loop = true;
    audio.volume = 0.5;
    audioRef.current = audio;

    return () => {
      audio.pause();
      audioRef.current = null;
    };
  }, []);

  const toggleMusic = () => {
    if (audioRef.current) {
      if (isMusicPlaying) {
        audioRef.current.pause();
      } else {
        // Resume context if needed (browsers block autoplay)
        audioRef.current.play().catch(e => console.log("Audio play failed:", e));
      }
      setIsMusicPlaying(!isMusicPlaying);
    }
  };

  // Keep ref in sync for gesture loop
  useEffect(() => {
    modeRef.current = mode;
  }, [mode]);

  const handleUpload = (files: FileList) => {
    const newPhotos = Array.from(files).map(file => URL.createObjectURL(file));
    setPhotos(prev => [...prev, ...newPhotos]);
  };

  // Initialize Gesture Recognizer and Camera
  useEffect(() => {
    let recognizer: GestureRecognizer | null = null;
    let animationFrameId: number;

    const startCamera = async () => {
      if (!isCameraEnabled) return;

      try {
        const vision = await FilesetResolver.forVisionTasks(
          "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm"
        );
        recognizer = await GestureRecognizer.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: "https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/1/gesture_recognizer.task",
            delegate: "GPU"
          },
          runningMode: "VIDEO"
        });

        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.onloadeddata = () => {
              setCameraLoaded(true);
              predict();
            };
          }
        }
      } catch (err) {
        console.warn("Camera/Gesture init warning:", err);
        setCameraLoaded(false);
      }
    };

    const predict = () => {
      if (!isCameraEnabled) return;

      if (videoRef.current && recognizer && videoRef.current.readyState === 4) {
        const results = recognizer.recognizeForVideo(videoRef.current, Date.now());
        
        // Default to inactive
        gestureState.active = false;

        if (results.gestures.length > 0) {
          const gesture = results.gestures[0][0];
          
          // Logic: Open Palm -> Scatter & Interaction
          if (gesture.categoryName === "Open_Palm" && gesture.score > 0.5) {
             // Trigger mode change if needed
             if (modeRef.current !== TreeState.SCATTERED) {
               setMode(TreeState.SCATTERED);
             }

             // Update continuous interaction state
             gestureState.active = true;
             
             // Get Hand Coordinates
             // Landmarks[0][9] is the middle finger MCP (roughly center of palm)
             if (results.landmarks && results.landmarks[0] && results.landmarks[0][9]) {
                gestureState.x = results.landmarks[0][9].x;
             }
          }
          
          // Logic: Closed Fist -> Recover Tree
          if (gesture.categoryName === "Closed_Fist" && gesture.score > 0.5) {
             if (modeRef.current !== TreeState.TREE_SHAPE) {
               setMode(TreeState.TREE_SHAPE);
             }
          }
        }
      }
      animationFrameId = requestAnimationFrame(predict);
    };

    if (isCameraEnabled) {
      startCamera();
    } else {
      setCameraLoaded(false);
    }

    return () => {
      // Force reset interaction state so it doesn't get stuck
      gestureState.active = false; 
      
      if (recognizer) recognizer.close();
      cancelAnimationFrame(animationFrameId);
      if (videoRef.current && videoRef.current.srcObject) {
         const stream = videoRef.current.srcObject as MediaStream;
         stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isCameraEnabled]);

  // Disable 3D interaction if viewing a photo
  const interactionEnabled = !zoomedPhoto;

  return (
    <div className="relative w-full h-screen bg-black">
      
      {/* 2D UI Layer */}
      <UI 
        mode={mode} 
        setMode={setMode} 
        onUpload={handleUpload} 
        zoomedPhoto={zoomedPhoto}
        setZoomedPhoto={setZoomedPhoto}
        toggleMusic={toggleMusic}
        isMusicPlaying={isMusicPlaying}
        isCameraEnabled={isCameraEnabled}
        setIsCameraEnabled={setIsCameraEnabled}
      />

      {/* Camera Preview */}
      {isCameraEnabled && (
        <div className="absolute bottom-4 right-4 z-40 w-32 h-24 rounded-lg overflow-hidden border border-white/20 shadow-lg opacity-80 pointer-events-none">
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            muted 
            className="w-full h-full object-cover transform scale-x-[-1]" 
          />
          {!cameraLoaded && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-[10px] text-white font-mono">
              LOADING...
            </div>
          )}
        </div>
      )}

      {/* 3D Scene Layer */}
      <Canvas
        camera={{ position: [0, 0, 45], fov: 35, near: 0.1, far: 200 }}
        dpr={[1, 2]} 
        gl={{ 
          antialias: false, 
          toneMappingExposure: 1.5,
          alpha: false
        }}
      >
        <Suspense fallback={null}>
          <Environment />
          
          <InteractiveGroup mode={mode}>
            <Fireworks mode={mode} />
            <TreeParticles mode={mode} />
            <PhotoParticles 
              mode={mode} 
              photos={photos} 
              onPhotoClick={(url) => {
                 if (url) setZoomedPhoto(url);
              }} 
            />
          </InteractiveGroup>
          
          <OrbitControls 
            enabled={interactionEnabled}
            enablePan={false}
            enableZoom={true}
            minDistance={10}
            maxDistance={80}
            autoRotate={mode === TreeState.TREE_SHAPE && interactionEnabled}
            autoRotateSpeed={0.5}
            dampingFactor={0.05}
          />
        </Suspense>
      </Canvas>
      
      <Loader 
        containerStyles={{ background: '#000502' }}
        barStyles={{ background: '#FFD700', height: '2px' }}
        dataStyles={{ fontFamily: 'Inter', color: '#0f5c3e', fontSize: '10px', textTransform: 'uppercase', letterSpacing: '0.2em' }}
      />
    </div>
  );
};

export default App;