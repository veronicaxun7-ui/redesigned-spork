export enum TreeState {
  SCATTERED = 'SCATTERED',
  TREE_SHAPE = 'TREE_SHAPE'
}

export interface TreeConfig {
  needleCount: number;
  ornamentCount: number;
  treeHeight: number;
  treeRadius: number;
  scatterRadius: number;
}

export interface PositionData {
  treePosition: [number, number, number];
  scatterPosition: [number, number, number];
  rotation: [number, number, number];
  scale: number;
}