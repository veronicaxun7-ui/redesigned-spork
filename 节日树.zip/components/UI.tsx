import React, { useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { TreeState } from '../types';
import { Sparkles, Box, Cuboid, Upload, X, Music, Camera, CameraOff } from 'lucide-react';

interface UIProps {
  mode: TreeState;
  setMode: (mode: TreeState) => void;
  onUpload: (files: FileList) => void;
  zoomedPhoto: string | null;
  setZoomedPhoto: (url: string | null) => void;
  toggleMusic: () => void;
  isMusicPlaying: boolean;
  isCameraEnabled: boolean;
  setIsCameraEnabled: (enabled: boolean) => void;
}

export const UI: React.FC<UIProps> = ({ 
  mode, setMode, onUpload, zoomedPhoto, setZoomedPhoto, toggleMusic, isMusicPlaying,
  isCameraEnabled, setIsCameraEnabled
}) => {
  const isTree = mode === TreeState.TREE_SHAPE;
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onUpload(e.target.files);
    }
  };

  return (
    <>
      <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-8 md:p-12 z-10">
        
        {/* Header - Controls Only */}
        <header className="flex justify-end items-start w-full">
          <div className="flex gap-4 pointer-events-auto items-center">
             {/* Camera Toggle */}
             <button 
                onClick={() => setIsCameraEnabled(!isCameraEnabled)}
                className={`p-2 rounded-full border transition-all ${isCameraEnabled ? 'bg-white/10 border-white/20 text-white' : 'bg-red-500/20 border-red-500 text-red-400'}`}
                title={isCameraEnabled ? "Turn Camera Off" : "Turn Camera On"}
             >
                {isCameraEnabled ? <Camera size={14} /> : <CameraOff size={14} />}
             </button>

             {/* Music Toggle */}
             <button 
                onClick={toggleMusic}
                className={`p-2 rounded-full border transition-all ${isMusicPlaying ? 'bg-yellow-500/20 border-yellow-500 text-yellow-400' : 'bg-white/10 border-white/20 text-white'}`}
             >
                <Music size={14} className={isMusicPlaying ? 'animate-pulse' : ''} />
             </button>

             {/* Upload Button */}
             <button 
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 rounded-full text-white text-xs uppercase tracking-widest transition-all"
             >
                <Upload size={14} />
                <span>Add Photos</span>
             </button>
             <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                multiple 
                accept="image/*" 
                onChange={handleFileChange}
             />
          </div>
        </header>

        {/* Interaction Controls */}
        <div className="flex flex-col items-center justify-center pointer-events-auto">
          <button
            onClick={() => setMode(isTree ? TreeState.SCATTERED : TreeState.TREE_SHAPE)}
            className="group relative px-8 py-4 bg-transparent overflow-hidden rounded-full border border-yellow-600/50 hover:border-yellow-500 transition-colors duration-500 backdrop-blur-sm"
          >
            {/* Button Background Glow */}
            <div className="absolute inset-0 bg-yellow-900/20 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out" />
            
            <div className="relative flex items-center gap-3 text-yellow-100 group-hover:text-white">
              {isTree ? <Box className="w-5 h-5" /> : <Cuboid className="w-5 h-5" />}
              <span className="uppercase tracking-widest text-sm font-semibold">
                {isTree ? "Scatter" : "Gather"}
              </span>
            </div>
          </button>
        </div>

        {/* Footer / Status */}
        <footer className="flex justify-between items-end">
          <div className="text-white/30 text-xs font-mono">
            <p>LAT: 48.8566 N</p>
            <p>LON: 2.3522 E</p>
          </div>
          <div className="flex gap-4 text-emerald-600/50">
             <Sparkles className="w-6 h-6 animate-pulse" />
          </div>
        </footer>
      </div>

      {/* Zoom Overlay */}
      <AnimatePresence>
        {zoomedPhoto && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-black/90 p-4 sm:p-10 cursor-pointer"
            onClick={() => setZoomedPhoto(null)}
          >
            <motion.div 
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.8, y: 20 }}
              className="relative max-w-full max-h-full"
            >
              <img 
                src={zoomedPhoto} 
                alt="Memory" 
                className="max-h-[85vh] max-w-[90vw] object-contain border-8 border-white rounded-sm shadow-2xl" 
              />
              <button 
                className="absolute -top-12 right-0 text-white/50 hover:text-white"
                onClick={() => setZoomedPhoto(null)}
              >
                <X size={32} />
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};