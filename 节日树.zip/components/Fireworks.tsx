import React, { useRef, useMemo, useEffect } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { TreeState } from '../types';

interface FireworksProps {
  mode: TreeState;
}

const COUNT = 400;

export const Fireworks: React.FC<FireworksProps> = ({ mode }) => {
  const pointsRef = useRef<THREE.Points>(null);
  const active = useRef(false);
  const time = useRef(0);

  // Generate particles
  const { positions, colors, velocities } = useMemo(() => {
    const pos = new Float32Array(COUNT * 3);
    const col = new Float32Array(COUNT * 3);
    const vel = [];
    const colorOptions = [new THREE.Color('#FFD700'), new THREE.Color('#FF0000'), new THREE.Color('#FFFFFF')];

    for (let i = 0; i < COUNT; i++) {
      // Start at center roughly
      pos[i * 3] = (Math.random() - 0.5) * 2;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 10;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 2;

      // Random color
      const c = colorOptions[Math.floor(Math.random() * colorOptions.length)];
      col[i * 3] = c.r;
      col[i * 3 + 1] = c.g;
      col[i * 3 + 2] = c.b;

      // Velocity: Explosion outward
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      const speed = 0.2 + Math.random() * 0.5;
      
      vel.push({
        x: speed * Math.sin(phi) * Math.cos(theta),
        y: speed * Math.sin(phi) * Math.sin(theta),
        z: speed * Math.cos(phi)
      });
    }

    return { positions: pos, colors: col, velocities: vel };
  }, []);

  // Reset/Trigger when mode changes to SCATTERED
  useEffect(() => {
    if (mode === TreeState.SCATTERED) {
      active.current = true;
      time.current = 0;
      
      // Reset positions to center-ish
      if (pointsRef.current) {
        const attr = pointsRef.current.geometry.attributes.position as THREE.BufferAttribute;
        for (let i = 0; i < COUNT; i++) {
          attr.setXYZ(i, (Math.random() - 0.5) * 2, (Math.random() - 0.5) * 10, (Math.random() - 0.5) * 2);
        }
        attr.needsUpdate = true;
      }
    } else {
      active.current = false;
    }
  }, [mode]);

  useFrame(() => {
    if (!active.current || !pointsRef.current) return;

    time.current += 0.01;
    // Stop after a few seconds
    if (time.current > 2.0) {
      active.current = false;
      // Hide them by moving far away
      const attr = pointsRef.current.geometry.attributes.position as THREE.BufferAttribute;
        for (let i = 0; i < COUNT; i++) {
          attr.setXYZ(i, 9999, 9999, 9999);
        }
        attr.needsUpdate = true;
      return;
    }

    const attr = pointsRef.current.geometry.attributes.position as THREE.BufferAttribute;
    
    // Animate
    for (let i = 0; i < COUNT; i++) {
      const vx = velocities[i].x;
      const vy = velocities[i].y;
      const vz = velocities[i].z;

      const currX = attr.getX(i);
      const currY = attr.getY(i);
      const currZ = attr.getZ(i);

      // Add gravity effect
      const gravity = -0.1 * time.current * time.current;

      attr.setXYZ(i, currX + vx, currY + vy + gravity, currZ + vz);
    }
    attr.needsUpdate = true;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={positions.length / 3}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={colors.length / 3}
          array={colors}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.8}
        vertexColors
        transparent
        opacity={0.8}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </points>
  );
};