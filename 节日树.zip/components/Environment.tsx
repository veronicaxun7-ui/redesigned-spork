import React from 'react';
import { Environment as DreiEnvironment, Sparkles, Stars } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette, Noise } from '@react-three/postprocessing';
import { COLORS } from '../constants';

export const Environment: React.FC = () => {
  return (
    <>
      {/* Background Ambience */}
      <color attach="background" args={[COLORS.bg]} />
      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
      
      {/* Ambient Snow */}
      <Sparkles 
        count={500} 
        scale={[30, 30, 30]} 
        size={3} 
        speed={0.5} 
        opacity={0.6} 
        color="#ffffff" 
        position={[0, 5, 0]}
      />
      
      {/* Cinematic Lighting */}
      <ambientLight intensity={0.2} color={COLORS.emeraldDeep} />
      
      {/* Main Key Light */}
      <spotLight 
        position={[20, 50, 20]} 
        angle={0.25} 
        penumbra={1} 
        intensity={2} 
        color={COLORS.glow}
        castShadow 
      />
      
      {/* Rim Light for Gold Highlights */}
      <pointLight position={[-10, 0, -10]} intensity={2} color={COLORS.gold} />
      
      {/* Internal Tree Glow (Warm) */}
      <pointLight position={[0, 0, 0]} intensity={1.5} color="#ffaa00" distance={15} decay={2} />

      {/* Floating Dust/Magic (Gold) */}
      <Sparkles 
        count={200} 
        scale={20} 
        size={4} 
        speed={0.4} 
        opacity={0.5} 
        color={COLORS.gold} 
      />

      {/* Reflections */}
      <DreiEnvironment preset="city" />

      {/* Post Processing */}
      <EffectComposer disableNormalPass>
        <Bloom 
          luminanceThreshold={0.6} 
          mipmapBlur 
          intensity={1.2} 
          radius={0.6} 
          levels={9} // High levels for cinematic bleed
        />
        <Vignette eskil={false} offset={0.1} darkness={1.1} />
        <Noise opacity={0.02} /> 
      </EffectComposer>
    </>
  );
};