import React, { useRef, useMemo, useLayoutEffect } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { CONFIG, COLORS, ORNAMENT_COLORS, GIFT_COLORS } from '../constants';
import { TreeState, PositionData } from '../types';

interface TreeParticlesProps {
  mode: TreeState;
}

const dummy = new THREE.Object3D();
const _position = new THREE.Vector3();
const _target = new THREE.Vector3();
const _color = new THREE.Color();

// Helper to generate random points in a cone (Tree Shape)
export const getConePoint = (h: number, r: number): [number, number, number] => {
  const y = Math.random() * h;
  const yNorm = y / h;
  const rAtHeight = r * (1 - yNorm);
  
  const theta = Math.random() * Math.PI * 2;
  const dist = Math.sqrt(Math.random()) * rAtHeight;
  
  const x = dist * Math.cos(theta);
  const z = dist * Math.sin(theta);
  
  return [x, y - h / 2, z];
};

// Helper to generate random points in a sphere (Scattered Shape)
export const getSpherePoint = (r: number): [number, number, number] => {
  const u = Math.random();
  const v = Math.random();
  const theta = 2 * Math.PI * u;
  const phi = Math.acos(2 * v - 1);
  const radius = Math.cbrt(Math.random()) * r;
  
  const x = radius * Math.sin(phi) * Math.cos(theta);
  const y = radius * Math.sin(phi) * Math.sin(theta);
  const z = radius * Math.cos(phi);
  
  return [x, y, z];
};

export const TreeParticles: React.FC<TreeParticlesProps> = ({ mode }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const ornamentsRef = useRef<THREE.InstancedMesh>(null);
  const giftsRef = useRef<THREE.InstancedMesh>(null);

  const { needlesData, ornamentsData, giftsData } = useMemo(() => {
    const needles: PositionData[] = [];
    const ornaments: PositionData[] = [];
    const gifts: PositionData[] = [];

    // Needles (Structure)
    for (let i = 0; i < CONFIG.needleCount; i++) {
      needles.push({
        treePosition: getConePoint(CONFIG.treeHeight, CONFIG.treeRadius),
        scatterPosition: getSpherePoint(CONFIG.scatterRadius),
        rotation: [Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI],
        scale: 0.5 + Math.random() * 0.5,
      });
    }

    // Ornaments (30% remaining)
    for (let i = 0; i < CONFIG.ornamentCount; i++) {
      const h = CONFIG.treeHeight;
      const y = Math.random() * h;
      const yNorm = y / h;
      const rAtHeight = CONFIG.treeRadius * (1 - yNorm);
      
      const theta = Math.random() * Math.PI * 2;
      const dist = rAtHeight * (0.8 + Math.random() * 0.3); 
      
      const treeX = dist * Math.cos(theta);
      const treeZ = dist * Math.sin(theta);

      ornaments.push({
        treePosition: [treeX, y - h / 2, treeZ],
        scatterPosition: getSpherePoint(CONFIG.scatterRadius * 1.2),
        rotation: [0, 0, 0],
        scale: 1 + Math.random(),
      });
    }

    // Gifts (30% remaining)
    for (let i = 0; i < CONFIG.giftCount; i++) {
      const h = CONFIG.treeHeight;
      const y = Math.random() * (h * 0.4); 
      const yNorm = y / h;
      const rAtHeight = CONFIG.treeRadius * (1 - yNorm);
      
      const theta = Math.random() * Math.PI * 2;
      const dist = rAtHeight * (0.9 + Math.random() * 0.4);
      
      const treeX = dist * Math.cos(theta);
      const treeZ = dist * Math.sin(theta);

      gifts.push({
        treePosition: [treeX, y - h / 2, treeZ],
        scatterPosition: getSpherePoint(CONFIG.scatterRadius * 1.0),
        rotation: [Math.random() * Math.PI, Math.random() * Math.PI, 0],
        scale: 0.8 + Math.random() * 0.5,
      });
    }

    return { needlesData: needles, ornamentsData: ornaments, giftsData: gifts };
  }, []);

  useLayoutEffect(() => {
    if (ornamentsRef.current) {
      ornamentsData.forEach((_, i) => {
        const colorHex = ORNAMENT_COLORS[Math.floor(Math.random() * ORNAMENT_COLORS.length)];
        _color.set(colorHex);
        ornamentsRef.current!.setColorAt(i, _color);
      });
      ornamentsRef.current.instanceColor!.needsUpdate = true;
    }
    if (giftsRef.current) {
      giftsData.forEach((_, i) => {
        const colorHex = GIFT_COLORS[Math.floor(Math.random() * GIFT_COLORS.length)];
        _color.set(colorHex);
        giftsRef.current!.setColorAt(i, _color);
      });
      giftsRef.current.instanceColor!.needsUpdate = true;
    }
  }, [ornamentsData, giftsData]);

  const progress = useRef(0);

  useFrame((state, delta) => {
    const target = mode === TreeState.TREE_SHAPE ? 1 : 0;
    const speed = delta / CONFIG.transitionDuration;
    if (Math.abs(progress.current - target) > 0.001) {
      progress.current = THREE.MathUtils.lerp(progress.current, target, speed * 4);
    }
    const t = progress.current;
    const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

    if (meshRef.current) {
      needlesData.forEach((data, i) => {
        _position.set(...data.scatterPosition).lerp(_target.set(...data.treePosition), ease);
        if (t < 0.8) _position.y += Math.sin(state.clock.elapsedTime + i) * 0.05 * (1 - t);
        dummy.position.copy(_position);
        dummy.rotation.set(data.rotation[0], data.rotation[1], data.rotation[2]);
        const s = data.scale * (0.5 + 0.5 * ease); 
        dummy.scale.set(s, s, s);
        dummy.updateMatrix();
        meshRef.current!.setMatrixAt(i, dummy.matrix);
      });
      meshRef.current.instanceMatrix.needsUpdate = true;
    }

    if (ornamentsRef.current) {
      ornamentsData.forEach((data, i) => {
        _position.set(...data.scatterPosition).lerp(_target.set(...data.treePosition), ease);
        dummy.position.copy(_position);
        dummy.rotation.set(0, state.clock.elapsedTime * 0.2 + i, 0);
        dummy.scale.setScalar(data.scale);
        dummy.updateMatrix();
        ornamentsRef.current!.setMatrixAt(i, dummy.matrix);
      });
      ornamentsRef.current.instanceMatrix.needsUpdate = true;
    }

    if (giftsRef.current) {
      giftsData.forEach((data, i) => {
        _position.set(...data.scatterPosition).lerp(_target.set(...data.treePosition), ease);
        dummy.position.copy(_position);
        dummy.rotation.set(data.rotation[0], state.clock.elapsedTime * 0.1 + i, data.rotation[2]);
        dummy.scale.setScalar(data.scale);
        dummy.updateMatrix();
        giftsRef.current!.setMatrixAt(i, dummy.matrix);
      });
      giftsRef.current.instanceMatrix.needsUpdate = true;
    }
  });

  return (
    <group>
      <instancedMesh ref={meshRef} args={[undefined, undefined, CONFIG.needleCount]}>
        <coneGeometry args={[0.1, 0.4, 3]} />
        <meshStandardMaterial color={COLORS.emeraldDeep} emissive={COLORS.emeraldLight} emissiveIntensity={0.2} roughness={0.4} />
      </instancedMesh>

      <instancedMesh ref={ornamentsRef} args={[undefined, undefined, CONFIG.ornamentCount]}>
        <sphereGeometry args={[0.25, 16, 16]} />
        <meshStandardMaterial color="#ffffff" roughness={0.1} metalness={0.9} envMapIntensity={2} />
      </instancedMesh>

      <instancedMesh ref={giftsRef} args={[undefined, undefined, CONFIG.giftCount]}>
        <boxGeometry args={[0.6, 0.6, 0.6]} />
        <meshStandardMaterial color="#ffffff" roughness={0.3} metalness={0.4} envMapIntensity={1} />
      </instancedMesh>
    </group>
  );
};