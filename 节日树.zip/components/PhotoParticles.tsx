import React, { useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { useFrame, useLoader } from '@react-three/fiber';
import { Image } from '@react-three/drei';
import { CONFIG } from '../constants';
import { TreeState, PositionData } from '../types';
import { getConePoint, getSpherePoint } from './TreeParticles';

interface PhotoParticlesProps {
  mode: TreeState;
  photos: string[];
  onPhotoClick: (url: string) => void;
}

// Festive Christmas Palette for frames
const FRAME_COLORS = [
  '#D42426', // Christmas Red
  '#146B3A', // Evergreen
  '#FFD700', // Gold
  '#F8B229', // Warm Yellow
  '#B76E79', // Rose Gold
  '#FFFFFF', // Snow White
  '#1E3F66', // Winter Night Blue
];

const PhotoItem: React.FC<{
  data: PositionData;
  mode: TreeState;
  url?: string;
  index: number;
  onClick: () => void;
}> = ({ data, mode, url, index, onClick }) => {
  const meshRef = useRef<THREE.Group>(null);
  const progress = useRef(0);
  const randomOffset = useMemo(() => Math.random() * 100, []);
  
  // Select a frame color based on index
  const frameColor = useMemo(() => {
    return FRAME_COLORS[index % FRAME_COLORS.length];
  }, [index]);

  useFrame((state, delta) => {
    const target = mode === TreeState.TREE_SHAPE ? 1 : 0;
    const speed = delta / CONFIG.transitionDuration;
    
    // Smooth transition
    progress.current = THREE.MathUtils.lerp(progress.current, target, speed * 3);
    const t = progress.current;
    
    // Ease
    const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

    if (meshRef.current) {
      // Interpolate Position
      const currentPos = new THREE.Vector3().set(...data.scatterPosition)
        .lerp(new THREE.Vector3().set(...data.treePosition), ease);
      
      // Floating animation when scattered
      if (t < 0.5) {
        currentPos.y += Math.sin(state.clock.elapsedTime + randomOffset) * 0.05;
        currentPos.x += Math.cos(state.clock.elapsedTime * 0.5 + randomOffset) * 0.02;
      }
      
      meshRef.current.position.copy(currentPos);

      // Interpolate Rotation
      // Tree: Fixed rotation (roughly facing out)
      // Scattered: Random floating rotation
      const scatterRot = new THREE.Euler(
        data.rotation[0] + state.clock.elapsedTime * 0.1,
        data.rotation[1] + state.clock.elapsedTime * 0.05,
        data.rotation[2]
      );
      
      // Calculate 'Face Out' rotation for Tree shape
      const angle = Math.atan2(currentPos.x, currentPos.z);
      const treeRot = new THREE.Euler(0, angle, 0);

      // Lerp rotation (simplified by just lerping Euler components)
      meshRef.current.rotation.x = THREE.MathUtils.lerp(scatterRot.x, treeRot.x, ease);
      meshRef.current.rotation.y = THREE.MathUtils.lerp(scatterRot.y, treeRot.y, ease);
      meshRef.current.rotation.z = THREE.MathUtils.lerp(scatterRot.z, treeRot.z, ease);
      
      // Scale
      const s = data.scale * (0.8 + 0.4 * ease);
      meshRef.current.scale.setScalar(s);
    }
  });

  const handleClick = (e: any) => {
    e.stopPropagation();
    // Only clickable in scattered mode
    if (mode === TreeState.SCATTERED) {
      onClick();
    }
  };

  return (
    <group ref={meshRef} onClick={handleClick}>
      {/* Photo Frame (Colored Paper) */}
      <mesh position={[0, 0, -0.01]}>
        <planeGeometry args={[1.2, 1.4]} />
        <meshStandardMaterial color={frameColor} roughness={0.4} metalness={0.1} side={THREE.DoubleSide} />
      </mesh>
      
      {/* The Image */}
      {url ? (
        <Image 
          url={url} 
          scale={[1, 1]} 
          position={[0, 0.1, 0]} 
          transparent
          opacity={0.9}
        />
      ) : (
        // Placeholder inner rectangle
        <mesh position={[0, 0.1, 0]}>
          <planeGeometry args={[1, 1]} />
          <meshStandardMaterial color="#333333" roughness={0.5} />
        </mesh>
      )}
    </group>
  );
};

export const PhotoParticles: React.FC<PhotoParticlesProps> = ({ mode, photos, onPhotoClick }) => {
  const photosData = useMemo(() => {
    const data: PositionData[] = [];
    for (let i = 0; i < CONFIG.photoCount; i++) {
      const h = CONFIG.treeHeight;
      const y = Math.random() * h;
      const yNorm = y / h;
      const rAtHeight = CONFIG.treeRadius * (1 - yNorm);
      
      // Distribute mostly on surface
      const theta = Math.random() * Math.PI * 2;
      const dist = rAtHeight * (0.9 + Math.random() * 0.2);
      
      const treeX = dist * Math.cos(theta);
      const treeZ = dist * Math.sin(theta);

      data.push({
        treePosition: [treeX, y - h / 2, treeZ],
        scatterPosition: getSpherePoint(CONFIG.scatterRadius * 0.8),
        rotation: [Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * 0.2],
        scale: 0.8 + Math.random() * 0.4,
      });
    }
    return data;
  }, []);

  return (
    <>
      {photosData.map((data, i) => (
        <PhotoItem 
          key={i} 
          index={i}
          data={data} 
          mode={mode} 
          url={photos.length > 0 ? photos[i % photos.length] : undefined}
          onClick={() => onPhotoClick(photos.length > 0 ? photos[i % photos.length] : '')}
        />
      ))}
    </>
  );
};