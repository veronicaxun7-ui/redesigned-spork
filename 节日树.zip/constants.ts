export const COLORS = {
  bg: '#000502',
  emeraldDeep: '#022618',
  emeraldLight: '#0f5c3e',
  gold: '#FFD700',
  roseGold: '#B76E79',
  glow: '#FFFAE0'
};

export const ORNAMENT_COLORS = [
  '#FFD700', // Gold
  '#D42426', // Red
  '#C0C0C0', // Silver
  '#1E3F66', // Blue
  '#B76E79', // Rose Gold
];

export const GIFT_COLORS = [
  '#8B0000', // Dark Red
  '#006400', // Dark Green
  '#4B0082', // Indigo
  '#FFD700', // Gold
];

export const CONFIG = {
  // Increased density significantly
  needleCount: 15000,
  // Reduced to ~30%
  ornamentCount: 100, 
  giftCount: 20,
  // The remaining ~70% as photos
  photoCount: 200, 
  
  treeHeight: 18,
  treeRadius: 7,
  scatterRadius: 35,
  transitionDuration: 2.5, // seconds
};